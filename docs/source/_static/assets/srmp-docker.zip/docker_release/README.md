# SRMP MoveIt Docker Release

This package contains everything you need to run SRMP (Search-based Robot Motion Planning) with MoveIt in a Docker container. The container includes MoveIt, the SRMP libraries, and pre-built user workspace.


## Simple Usage Summary

1. **Build**: `./build-srmp-docker.sh`
2. **Run**: `./run-srmp-docker.sh`
3. **Setup workspace** (inside container):
   ```bash
   cd /workspace/srmp_user_ws
   catkin build
   source devel/setup.bash
   ```
4. **Test**: `roslaunch panda_two_moveit_config demo.launch`
5. **RViz**: `rviz`

That's it! Below, we include some more details.

---

## What's Included

- **MoveIt**: Complete MoveIt installation with all planners and tools
- **SRMP Libraries**
- **User Workspace**: Pre-built workspace with SRMP MoveIt plugin and resources
- **RViz**: ROS visualization tool
- **Robot Configuration**: Panda robot configuration for testing

## Quick Start

### Prerequisites

- Docker installed on your system
- X11 forwarding enabled (for GUI applications like RViz)

### Installation

1. **Extract the package**:
   ```bash
   unzip srmp-docker.zip
   cd docker_release
   ```

2. **Build the Docker image**:
   ```bash
   ./build-srmp-docker.sh
   ```
   *This may take 10-15 minutes on first build*

3. **Run the container**:
   ```bash
   ./run-srmp-docker.sh
   ```

4. **Set up the workspace** (inside the container):
   ```bash
   # Navigate to the workspace
   cd /workspace/srmp_user_ws
   
   # Build the workspace
   catkin build
   
   # Source the workspace
   source devel/setup.bash
   ```

5. **Test SRMP**:
   ```bash
   # Inside the container
   roslaunch panda_two_moveit_config demo.launch
   ```

## Using RViz

The container automatically sets up X11 forwarding for GUI applications:

1. **Run the container**:
   ```bash
   ./run-srmp-docker.sh
   ```

2. **Set up the workspace** (inside the container):
   ```bash
   # Navigate to the workspace
   cd /workspace/srmp_user_ws
   
   # Build the workspace
   catkin build
   
   # Source the workspace
   source devel/setup.bash
   ```

3. **Test MoveIt with SRMP**:
   ```bash
   # Inside the container
   roslaunch panda_two_moveit_config demo.launch
   ```

## File Locations

Inside the container:
- **SRMP Libraries**: `/opt/ros/noetic/lib/`
  - `libsearch.so`
  - `libmanipulation_planning.so`
- **User Workspace**: `/workspace/srmp_user_ws/`
- **MoveIt Configurations**: `/workspace/srmp_user_ws/src/mramp_moveit_resources/`
- **SRMP Plugin**: `/workspace/srmp_user_ws/src/srmp_moveit_plugin/`

## Container Management

### Run the container
```bash
./run-srmp-docker.sh
```

### Stop the container
```bash
# Press Ctrl+C in the container terminal
# Or from host:
docker stop srmp-moveit
```

### Remove the container
```bash
docker rm srmp-moveit
```

### Remove the image
```bash
docker rmi srmp-moveit:latest
```

## Troubleshooting

### Container won't start
```bash
# Check Docker status
docker ps -a

# Check if image exists
docker images | grep srmp-moveit
```

### RViz won't display
```bash
# Enable X11 forwarding
xhost +local:docker

# Check DISPLAY variable
echo $DISPLAY

# Restart the container
./run-srmp-docker.sh
```

### Permission issues
```bash
# Add your user to docker group
sudo usermod -aG docker $USER
# Log out and back in
```

### Rebuild from scratch
```bash
# Remove old image
docker rmi srmp-moveit:latest

# Rebuild
./build-srmp-docker.sh
```

