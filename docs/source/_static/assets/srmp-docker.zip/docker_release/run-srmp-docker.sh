#!/bin/bash

# Simple SRMP Docker Container Script
# Based on the working test_rviz_docker.sh approach

set -e

echo "=== SRMP MoveIt Docker Container ==="
echo ""

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed or not in PATH"
    exit 1
fi

# Check if the package exists
if [ ! -f "ros-noetic-srmp-moveit_1.0.0_amd64.deb" ]; then
    echo "❌ Package file not found: ros-noetic-srmp-moveit_1.0.0_amd64.deb"
    echo "Please run the build script first"
    exit 1
fi

# Check if user workspace exists
if [ ! -d "srmp_user_ws" ]; then
    echo "❌ User workspace not found: srmp_user_ws"
    echo "Please run the build script first"
    exit 1
fi

# Check X11 forwarding
if [ -z "$DISPLAY" ]; then
    echo "❌ DISPLAY environment variable not set"
    echo "Please run: export DISPLAY=:0"
    exit 1
fi

echo "✓ Docker is available"
echo "✓ Package file found"
echo "✓ User workspace found"
echo "✓ DISPLAY is set to: $DISPLAY"
echo ""

# Allow X11 connections
echo "Setting up X11 forwarding..."
xhost +local:docker 2>/dev/null || echo "⚠️  Could not run xhost, GUI may not work"
echo ""

echo "🚀 Starting SRMP Docker container..."
echo ""

# Stop any existing container
docker stop srmp-moveit 2>/dev/null || true
docker rm srmp-moveit 2>/dev/null || true

# Run the Docker container with full GUI support (exactly like the working script)
docker run -it \
    --name srmp-moveit \
    --network host \
    --privileged \
    -e DISPLAY=$DISPLAY \
    -e QT_X11_NO_MITSHM=1 \
    -e XAUTHORITY=/root/.Xauthority \
    -v /tmp/.X11-unix:/tmp/.X11-unix:rw \
    -v ~/.Xauthority:/root/.Xauthority:rw \
    -v "$(pwd):/workspace" \
    srmp-moveit:latest \
    bash -c "
        echo '=== SRMP MoveIt Container Ready ==='
        echo ''
        echo 'SRMP libraries installed:'
        echo '  - Search library: /opt/ros/noetic/lib/libsearch.so'
        echo '  - Manipulation planning: /opt/ros/noetic/lib/libmanipulation_planning.so'
        echo ''
        echo 'User workspace available at: /workspace/srmp_user_ws'
        echo ''
        echo 'To test SRMP:'
        echo '  roslaunch panda_two_moveit_config demo.launch'
        echo ''
        echo 'To use RViz:'
        echo '  rviz'
        echo ''
        echo 'Container is ready for use!'
        echo '========================================='
        echo ''
        echo 'Starting interactive shell...'
        bash
    "

echo ""
echo "=== Container stopped ==="
echo ""
echo "To restart the container:"
echo "  ./run-srmp-docker.sh"
echo ""
echo "To remove the container:"
echo "  docker rm srmp-moveit"
