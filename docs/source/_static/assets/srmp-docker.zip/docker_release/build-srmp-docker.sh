#!/bin/bash

# Simple SRMP Docker Build Script
# Builds the Docker image with SRMP libraries and user workspace

set -e

echo "=== Building SRMP Docker Image ==="
echo ""

# Check if we're in the right directory
if [ ! -f "Dockerfile" ]; then
    echo "❌ Dockerfile not found. Please run this script from the docker_release directory"
    exit 1
fi

# Check if the package exists
if [ ! -f "ros-noetic-srmp-moveit_1.0.0_amd64.deb" ]; then
    echo "❌ Package file not found: ros-noetic-srmp-moveit_1.0.0_amd64.deb"
    echo "Please copy the package file to this directory first"
    exit 1
fi

# Check if user workspace exists
if [ ! -d "srmp_user_ws" ]; then
    echo "❌ User workspace not found: srmp_user_ws"
    echo "Please copy the user workspace to this directory first"
    exit 1
fi

echo "✓ Dockerfile found"
echo "✓ Package file found"
echo "✓ User workspace found"
echo ""

echo "🚀 Building Docker image..."
echo "This may take 10-15 minutes..."
echo ""

# Build the Docker image
docker build -t srmp-moveit:latest .

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Docker image built successfully!"
    echo ""
    echo "Image details:"
    docker images | grep srmp-moveit
    echo ""
    echo "To run the container:"
    echo "  ./run-srmp-docker.sh"
    echo ""
    echo "To test RViz:"
    echo "  ./run-srmp-docker.sh"
    echo "  # Then inside container: rviz"
else
    echo ""
    echo "❌ Docker build failed!"
    exit 1
fi
