# SRMP User Workspace

This workspace contains the user-buildable packages for SRMP (Search-based Robot Motion Planning):

- **srmp_moveit_plugin**: MoveIt plugin for SRMP motion planning
- **mramp_moveit_resources**: MoveIt configuration files and launch files

## Prerequisites

Before using this workspace, you must install the core library packages:

1. **Search Library Package**:
   ```bash
   sudo dpkg -i ros-noetic-search-library_1.0.0_amd64.deb
   ```

2. **Manipulation Planning Package**:
   ```bash
   sudo dpkg -i ros-noetic-manipulation-planning_1.0.0_amd64.deb
   ```

3. **MoveIt Packages** (if not already installed):
   ```bash
   sudo apt-get install ros-noetic-moveit-core ros-noetic-moveit-ros-planning ros-noetic-moveit-ros-planning-interface ros-noetic-moveit-msgs
   ```

## Quick Start

1. **Initialize workspace** (first time only):
   ```bash
   catkin_init_workspace src
   ```

2. **Build the workspace**:
   ```bash
   catkin build
   ```

3. **Source the workspace**:
   ```bash
   source devel/setup.bash
   ```

4. **Test the installation**:
   ```bash
   roslaunch panda_two_binpick_moveit_config demo.launch
   ```

## Package Contents

### srmp_moveit_plugin
- MoveIt plugin implementation for SRMP
- Factory functions for creating planners
- Heuristics and action spaces
- **Source code included** - users build this locally

### mramp_moveit_resources
- MoveIt configuration files
- Launch files for demos
- Robot descriptions and motion primitives
- **Source code included** - users build this locally

## Architecture

This workspace follows a layered architecture:

1. **Core Libraries** (installed via Debian packages):
   - `libsearch.so` - Core search algorithms
   - `libmanipulation_planning.so` - Manipulation planning framework
   - **No source code** - binary-only packages

2. **User Packages** (built locally):
   - `srmp_moveit_plugin` - MoveIt integration
   - `mramp_moveit_resources` - Configuration files
   - **Source code included** - users can modify and rebuild

## Troubleshooting

### Build Errors

If you encounter build errors:

1. **Check core library installation**:
   ```bash
   ls -la /opt/ros/noetic/lib/libsearch.so
   ls -la /opt/ros/noetic/lib/libmanipulation_planning.so
   ```

2. **Check MoveIt installation**:
   ```bash
   dpkg -l | grep moveit
   ```

3. **Clean and rebuild**:
   ```bash
   catkin clean
   catkin build
   ```

### Runtime Errors

If you encounter runtime errors:

1. **Check library dependencies**:
   ```bash
   ldd devel/lib/libmoveit_planners_srmp.so
   ```

2. **Verify ROS package discovery**:
   ```bash
   rospack find moveit_planners_srmp
   ```

## Support

For issues and questions:
- Check the main SRMP repository
- Contact the maintainers

## License

This software is provided under the same license as the main SRMP project.
