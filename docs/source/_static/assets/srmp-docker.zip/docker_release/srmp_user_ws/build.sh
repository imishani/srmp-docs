#!/bin/bash

# SRMP User Workspace Build Script
# This script builds the user workspace

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  SRMP User Workspace Build${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Source ROS environment
if [ -f "/opt/ros/noetic/setup.bash" ]; then
    source "/opt/ros/noetic/setup.bash"
else
    echo -e "${RED}Error: ROS Noetic not found${NC}"
    exit 1
fi

# Build workspace
cd "$(dirname "$0")"
catkin build

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Build successful${NC}"
    echo ""
    echo -e "${BLUE}To use the workspace:${NC}"
    echo "source devel/setup.bash"
else
    echo -e "${RED}✗ Build failed${NC}"
    exit 1
fi
