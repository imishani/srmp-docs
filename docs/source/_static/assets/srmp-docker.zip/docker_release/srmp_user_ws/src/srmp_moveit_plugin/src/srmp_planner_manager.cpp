/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2019, PickNik LLC
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of PickNik LLC nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************/

/* Author: Itamar Mishani
   Desc:   SRMP planning plugin
*/

#include <moveit/planning_interface/planning_interface.h>
#include <moveit/planning_interface/planning_response.h>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/collision_detection_fcl/collision_detector_allocator_fcl.h>
#include <moveit/collision_distance_field/collision_detector_allocator_hybrid.h>
#include <class_loader/class_loader.hpp>
#include <memory>
#include <pluginlib/class_list_macros.h>
#include "srmp_moveit_plugin/srmp_planning_context.hpp"

namespace srmp_interface
{
class SRMPPlannerManager : public planning_interface::PlannerManager
{
public:
    SRMPPlannerManager() : planning_interface::PlannerManager()
    {
    }

    bool initialize(const moveit::core::RobotModelConstPtr& model, const std::string& ns) override
    {
        for (const std::string& gpName : model->getJointModelGroupNames())
        {
            ROS_INFO_STREAM("Initializing SRMP Planning Context for group: " << gpName);
            planning_contexts_[gpName] =
                std::make_shared<SRMPPlanningContext>("srmp_planning_context", ns, gpName, model);
        }
    return true;
    }

    bool canServiceRequest(const moveit_msgs::MotionPlanRequest& req) const override
    {
        return req.trajectory_constraints.constraints.empty();
    }

    std::string getDescription() const override
    {
        return "SRMP: Search-based Robot Motion Planning";
    }

    void getPlanningAlgorithms(std::vector<std::string>& algs) const override
    {
        algs.clear();
        algs.emplace_back("Astar");
        algs.emplace_back("wAstar");
        algs.emplace_back("ARAstar");
        algs.emplace_back("MHAstar");
        algs.push_back("wPASE");

        // Multi-agent search algorithms.
        algs.push_back("xECBS");
        // algs.push_back("PP");
        // algs.push_back("ECBS");
    }

    planning_interface::PlanningContextPtr getPlanningContext(const planning_scene::PlanningSceneConstPtr& planning_scene,
                                                            const planning_interface::MotionPlanRequest& req,
                                                            moveit_msgs::MoveItErrorCodes& error_code) const override
    {
    error_code.val = moveit_msgs::MoveItErrorCodes::SUCCESS;

    if (req.group_name.empty())
    {
      ROS_ERROR("No group specified to plan for");
      error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_GROUP_NAME;
      return {};
    }

    if (!planning_scene)
    {
      ROS_ERROR("No planning scene supplied as input");
      error_code.val = moveit_msgs::MoveItErrorCodes::FAILURE;
      return {};
    }

    // retrieve and configure existing context
    const SRMPPlanningContextPtr& context = planning_contexts_.at(req.group_name);
    ROS_INFO_STREAM_NAMED("srmp_planner_manager", "===>>> context is made ");
    // // create PlanningScene using hybrid collision detector
    planning_scene::PlanningScenePtr ps = planning_scene->diff();

    // // set FCL for the collision
    ps->setActiveCollisionDetector(collision_detection::CollisionDetectorAllocatorFCL::create(), true);
    // ps->setActiveCollisionDetector(collision_detection::CollisionDetectorAllocatorHybrid::create(), true);

    context->setPlanningScene(ps);
    context->setMotionPlanRequest(req);

    error_code.val = moveit_msgs::MoveItErrorCodes::SUCCESS;
    return context;
    }

protected:
    std::map<std::string, SRMPPlanningContextPtr> planning_contexts_;
};

}  // namespace srmp_interface

// register the SRMPPlannerManager class as a plugin
//CLASS_LOADER_REGISTER_CLASS(srmp_interface::SRMPPlannerManager, planning_interface::PlannerManager);
PLUGINLIB_EXPORT_CLASS(srmp_interface::SRMPPlannerManager, planning_interface::PlannerManager);
