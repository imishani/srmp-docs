MRAMP MoveIt Resources
================

This repository is a subset of MoveIt! Resources, with some additions.

