# SRMP Installation Instructions

## Overview

SRMP (Search-based Robot Motion Planning) is distributed as:

1. **Core Libraries** (Debian packages) - Binary-only, no source code
2. **User Workspace** (Source code) - Users build locally

## Installation Steps

### Step 1: Install Core Libraries

Install the core library packages in order:

```bash
# Install search library
sudo dpkg -i ros-noetic-search-library_1.0.0_amd64.deb

# Install manipulation planning library
sudo dpkg -i ros-noetic-manipulation-planning_1.0.0_amd64.deb
```

### Step 2: Install MoveIt (if not already installed)

```bash
sudo apt-get update
sudo apt-get install ros-noetic-moveit-core ros-noetic-moveit-ros-planning ros-noetic-moveit-ros-planning-interface ros-noetic-moveit-msgs ros-noetic-dynamic-reconfigure
```

### Step 3: Setup User Workspace

```bash
cd srmp_user_ws
./setup_workspace.sh
```

### Step 4: Test Installation

```bash
source devel/setup.bash
roslaunch panda_two_binpick_moveit_config demo.launch
```

## Verification

### Check Core Libraries

```bash
# Check search library
ls -la /opt/ros/noetic/lib/libsearch.so

# Check manipulation planning library
ls -la /opt/ros/noetic/lib/libmanipulation_planning.so

# Check CMake configs
ls -la /opt/ros/noetic/share/search/cmake/
ls -la /opt/ros/noetic/share/manipulation_planning/cmake/
```

### Check User Packages

```bash
# Check plugin library
ls -la devel/lib/libmoveit_planners_srmp.so

# Check ROS package discovery
rospack find moveit_planners_srmp
rospack find mramp_moveit_resources
```

## Architecture Benefits

### For Users
- **Transparency**: Source code for user packages is available
- **Customization**: Users can modify and rebuild user packages
- **Compatibility**: Core libraries are version-agnostic

### For Developers
- **Protection**: Core algorithm source code is protected
- **Distribution**: Easy distribution via Debian packages
- **Maintenance**: Centralized updates for core libraries

## Troubleshooting

### Common Issues

1. **Missing dependencies**:
   ```bash
   sudo apt-get install -f
   ```

2. **Build failures**:
   ```bash
   catkin clean
   catkin build
   ```

3. **Runtime errors**:
   ```bash
   source devel/setup.bash
   rospack refresh
   ```

### Support

For technical support, contact the maintainers or check the main repository.
