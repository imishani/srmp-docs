# openarm: provenance

Enactic OpenArm v2.0, a single 7-DOF arm with the pinch gripper, mounted on its own base link
(no body/torso, no second arm).

## Upstream

- Repo: https://github.com/enactic/openarm_description
- Commit: `2e27c793e10aa2045e7eb597b9b9b9dc08fb0a08` ("Handle oblique axes in joint reflection (#104)")
- License: Apache-2.0 (`LICENSE.txt`, copied verbatim as `LICENSE`). Copyright 2025-2026 Enactic, Inc.
  No NOTICE file upstream.

## Hardware version

OpenArm **v2.0** (`assets/robot/openarm_v2.0`). The upstream README's "Recommended starting point"
section (currently inside an HTML comment in README.md) says: "for all new robot assembly, presets,
xacro, and URDF generation work, start with `assets/robot/openarm_v2.0`; only use
`assets/robot/openarm_v1.0` when you need the old `v10 + parallel_link` compatibility path".

## Files used

- `assets/robot/openarm_v2.0/urdf/openarm_v20.urdf.xacro` (entry point) and its includes in
  `assets/robot/openarm_v2.0/urdf/utils/`, `assets/common/`
- Preset `assets/robot/openarm_v2.0/config/robot_presets/right_arm_with_pinch_gripper.yaml`
  (upstream's single-arm preset: body disabled, secondary arm disabled, primary arm mounted on
  `world` at the identity, pinch gripper on `ee_mount_point`)
- Arm config `assets/robot/openarm_v2.0/config/arm/*`, gripper config
  `assets/end_effector/pinch_gripper/config/*`
- Meshes (copied unmodified):
  - `assets/robot/openarm_v2.0/meshes/arm/{visual/*.dae,collision/*.stl}` -> `meshes/arm/...`
    (base_link, link1..link6)
  - `assets/end_effector/pinch_gripper/meshes/{visual/*.dae,collision/*.stl}` -> `meshes/pinch_gripper/...`
    (ee_base_link, finger_inner, finger_outer)

## xacro

The standalone xacro cannot resolve `$(find openarm_description)`, so the repo was copied (without
`.git`) and every `$(find openarm_description)` was replaced by the copy's absolute path. Then:

```
xacro assets/robot/openarm_v2.0/urdf/openarm_v20.urdf.xacro \
    robot_preset:=right_arm_with_pinch_gripper \
    emit_grasp_frame:=true \
    collapse_internal_empty_links:=false
```

- `emit_grasp_frame:=true` emits upstream's `openarm_right_grasp_frame` (from
  `pinch_gripper/config/struct/reference_points.yaml`, 0.138 m below the gripper base, between the
  fingertips), used as the end effector. Its x axis is the approach direction.
- `collapse_internal_empty_links:=false` keeps upstream's canonical `link7` (the J7 output /
  flange, named in `config/arm/struct/topology.yaml`) and the fixed `openarm_right_ee_mount_joint`,
  instead of folding them into `ee_base_link`. Geometry is identical either way; this only keeps the
  flange frame.

## Changes to the xacro output

1. Removed both `<ros2_control>` blocks (upstream emits the bimanual hardware template, which
   names `openarm_left_*` joints that do not exist in the single-arm model).
2. Removed the empty root link `world` and the fixed `openarm_right_base_link_mount_joint`
   (identity transform), so `openarm_right_base_link` is the root.
3. Robot name `openarm_v20` -> `openarm`.
4. Mesh paths `package://openarm_description/assets/robot/openarm_v2.0/meshes/arm/` ->
   `meshes/arm/` and `package://openarm_description/assets/end_effector/pinch_gripper/meshes/` ->
   `meshes/pinch_gripper/`.

Nothing else changed: link/joint names (with upstream's preset prefix `openarm_right_`), origins,
axes, limits, inertials, mimic and visual/collision geometry are as xacro emitted them.
`openarm_right_camera_view_frame` (an empty fixed frame upstream emits) is kept.

## Base frame

As in upstream's single-arm preset, the base frame is the one the arm uses when bolted to the side
of the OpenArm torso: the mounting face is the base link's y=0 plane (normal +y), joint1 (shoulder)
axis is horizontal (-y), and at all-zeros the arm hangs straight down (-z) with the tool 0.57 m
below the base. Mount it on a table by giving the robot a base pose (e.g. rotate so +y points down).

## default_qpos

Upstream documents no home/ready pose (all ros2_control initial values are 0, which is the arm
hanging straight down). `default_qpos = [-0.6, pi, 0, 1.0, 0, -0.4, 0]` was chosen instead: joint2
at pi raises the upper arm overhead (elbow at z=0.17 m), the elbow bends the forearm forward and
down, and the grasp frame sits 0.47 m in front of the base at z=0.12 m, approaching forward and
down. Inside the limits and self-collision free (with the gripper open, see below).

## SRDF

Generated with `tools/generate_srdf.py openarm/openarm.urdf openarm/openarm.srdf
--end-effector openarm_right_grasp_frame --name openarm` (48 disabled pairs). Not edited.

## Known issue: gripper fully closed counts as self-collision

The finger collision meshes meet exactly at the y=0 plane when `finger_joint1 = 0` (fully closed,
the joint's upper limit); any opening (-1e-4 rad) clears them. srmp starts gripper joints at 0, and
the SRDF generator keeps the `ee_link1`/`ee_link2` pair enabled (the gripper is sampled over its
range, so the pair collides only sometimes). Result: every state with the gripper at its default
reports self-collision.
