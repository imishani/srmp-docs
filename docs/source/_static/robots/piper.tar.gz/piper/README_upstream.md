# piper: upstream provenance

- Repo: https://github.com/agilexrobotics/piper_ros
- Commit: ac41fcbcdda598f01b51cf6175ed9a24d0dacadc (2026-03-04)
- License: MIT (repo-root `LICENSE`, copied verbatim). The meshes live in the same repo
  (`src/piper_description/meshes/`), so the repo license covers them. Note:
  `src/piper_description/package.xml` declares `<license>BSD</license>`; the repo-level MIT
  LICENSE is the only license text upstream ships, so that is what is included.

## Files used

- `src/piper_description/urdf/piper_description.urdf` (plain URDF, no xacro run).
  Chosen because the upstream README ("Note the URDF version") says it is the default and
  matches firmware >= S-V1.6-3 (j2/j3 frames offset by 2 degrees); `piper_description_old.urdf`
  is for firmware < S-V1.6-3. The `_v100` / `_v100_camera` variants are a different model
  (`piper_camera` robot, `arm_base` root, `gripper_base_100_v2` gripper) not mentioned in
  the README; not used.
- Meshes: `src/piper_description/meshes/{base_link,link1..link8,gripper_base}.STL`
  (binary STL, same file used for visual and collision, as upstream).

## Changes

1. `package://piper_description/meshes/X.STL` -> `meshes/X.STL` (20 occurrences).
2. Whitespace inside XML tags collapsed (e.g. `<link\n    name="base_link">` ->
   `<link name="base_link">`). Purely cosmetic: element/attribute content is identical
   (checked by parsing both). Needed because srmp 0.2.1's URDF prefix injection
   (`applyUrdfPrefix`, regex `link name="..."`) does not match attributes on a new line,
   which made `generate_srdf.py` fail with "child link [piper_base_link] ... not found".
3. Nothing else: link/joint names, limits, origins, inertials unchanged. The upstream
   `dummy_link` root (fixed `base_to_dummy` joint) is kept.

## SRDF

Generated with
`python tools/generate_srdf.py piper/piper.urdf piper/piper.srdf --end-effector gripper_base --name piper`
(srmp 0.2.1).

## Manifest notes

- End effector: `gripper_base`, the link the fingers attach to. Upstream has no TCP/grasp
  frame between the fingers and documents no TCP offset, so none was added. (The finger
  joints' origin is 0.1358 m along gripper_base z, but that is a joint origin, not a
  documented TCP.)
- default_qpos: all zeros, the pose the upstream driver's `/go_zero_srv` ("Zero the
  Robotic Arm", README(EN).md section 2.2 (7)) moves to. It is the folded rest pose.
- Gripper: `joint7` (link7, [0, 0.035] m) and `joint8` (link8, [-0.035, 0] m) are two
  independent prismatic joints upstream (no `<mimic>`). At 0/0 (fully closed) the two
  finger collision meshes touch exactly (gap 0 at y = 0 in gripper_base frame).
