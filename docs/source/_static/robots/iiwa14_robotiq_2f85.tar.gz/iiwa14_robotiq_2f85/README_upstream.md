# iiwa14_robotiq_2f85: provenance

KUKA LBR iiwa 14 R820 with a Robotiq 2F-85 mounted on the flange. Composed from two entries
already staged in `registry_new/` (`iiwa14/` and `ur5e_robotiq_2f85/`). No xacro was run for
this entry.

## Sources

| Part | Upstream | Commit | License | File here |
|---|---|---|---|---|
| iiwa 14 arm | https://github.com/lbr-stack/lbr_iiwa14_r820_description | tag v2.5.0, 86ac0532841a90694afe6a65c300f08b55eb1296 | Apache-2.0 (package.xml; text from lbr_fri_ros2_stack f55f23d03e8dfeaafdd9d50fabf6a267445d753d) | `LICENSE` |
| Robotiq 2F-85 | https://github.com/PickNikRobotics/ros2_robotiq_gripper (`robotiq_description`) | a74d007d8f2f06dc6a503ad21038ba869d4999a6 | BSD-3-Clause (PickNik Robotics) | `LICENSE.robotiq` |

- `LICENSE` is copied byte-for-byte from `registry_new/iiwa14/LICENSE`, and `LICENSE.robotiq`
  from `registry_new/ur5e_robotiq_2f85/LICENSE.robotiq`.
- Arm meshes (`meshes/visual/link_0..7.dae`, `meshes/collision/link_0..7.stl`) are copied
  unchanged from `registry_new/iiwa14/meshes/`. See `iiwa14/README_upstream.md` for how that
  URDF was generated (xacro of `urdf/lbr_iiwa14_r820.urdf.xacro`, default args).
- Gripper meshes (`meshes/robotiq_2f_85/{visual,collision}/{robotiq_base,left_*,right_*}`,
  18 files) are copied unchanged from `registry_new/ur5e_robotiq_2f85/meshes/robotiq_2f_85/`.
  Those match PickNik's `robotiq_description/meshes/{visual,collision}/2f_85/` at the commit
  above. The UR coupling meshes (`ur_to_robotiq_adapter.*`) were not copied.

## What was done

1. Started from `iiwa14/iiwa14.urdf`, unchanged except `<robot name="lbr_iiwa14_r820">` became
   `<robot name="iiwa14_robotiq_2f85">`. All arm links, joints, limits, inertials and the
   `lbr_link_ee` flange frame (0.035 m beyond `lbr_link_7`) are the same.
2. Appended the 2F-85 block from `ur5e_robotiq_2f85.urdf` unchanged: links and joints
   `robotiq_85_*` with their limits, mimics, inertials and `<surface>` blocks, plus `grasp_link`
   (fixed, `xyz 0 0 0.1208` from `robotiq_85_base_link`, the same end effector as the
   ur5e/kinova Robotiq entries). The only edit: `robotiq_85_base_joint` now has
   `parent="lbr_link_ee"` (it was `gripper_mount_link`). Its origin stays identity.
3. NOT carried over: the UR-specific coupling (`ur_to_robotiq_joint`, `ur_to_robotiq_link`,
   `gripper_side_joint`, `gripper_mount_link`) and its meshes.

## Mounting: no coupling modelled (identity mount)

The real gripper needs a KUKA (ISO 9409-1-31.5) to Robotiq coupling between the iiwa media
flange and the gripper. PickNik's `robotiq_description` at the commit above only ships the UR
coupling (`ur_to_robotiq_adapter.urdf.xacro`) and the 2F-140's own coupling; it has no KUKA /
ISO 9409-1-31.5 coupling. Nothing in lbr_fri_ros2_stack, lbr_iiwa14_r820_description,
kuka_experimental or Drake `models` models one either. So `robotiq_85_base_link` is mounted
DIRECTLY on `lbr_link_ee` with an identity origin (no offset, no rotation, no coupling mesh).
A real coupling would add roughly 1-2 cm along the flange z-axis (and possibly a yaw about it);
none was invented here. Anyone using this with real hardware should add their coupling's
offset to `robotiq_85_base_joint`.

## SRDF

Generated (not hand-written), run from `registry_new/`:

    python /home/itamar/work/code/ims_manip/tools/generate_srdf.py iiwa14_robotiq_2f85/iiwa14_robotiq_2f85.urdf iiwa14_robotiq_2f85/iiwa14_robotiq_2f85.srdf --end-effector grasp_link --name iiwa14_robotiq_2f85

then corrected with `fix_srdf.py`:

    python fix_srdf.py iiwa14_robotiq_2f85/iiwa14_robotiq_2f85.srdf \
      --default robotiq_85_left_finger_tip_link:robotiq_85_left_inner_knuckle_link \
                robotiq_85_right_finger_tip_link:robotiq_85_right_inner_knuckle_link \
      --enable lbr_link_0:lbr_link_7 \
               lbr_link_0:robotiq_85_right_finger_link \
               lbr_link_0:robotiq_85_right_knuckle_link \
               lbr_link_1:robotiq_85_left_finger_tip_link

- `--default`: the two pairs reused from `ur5e_robotiq_2f85`. On the real gripper the finger
  tip and the inner knuckle are pinned together (a closed four-bar the URDF cannot express),
  so they touch at q_gripper = 0. The probe shows them colliding in 100% of samples.
- `--enable lbr_link_0:lbr_link_7`: the arm's own correction, carried over from the `iiwa14`
  entry. In this generated SRDF the generator had not disabled that pair, so this flag
  removed nothing. It is kept so that the pair stays enabled if the SRDF is regenerated.
- `--enable` (other three): `probe_srdf.py iiwa14_robotiq_2f85 iiwa14_robotiq_2f85.json 20000`
  reported these as HIDDEN, meaning real arm-to-gripper contacts that the generator had
  disabled. Each was seen in 1 of 20000 samples. After re-enabling them, the probe reports
  0 hidden pairs.

## default_qpos

`[0, 0.5, 0, -1.2, 0, 1.0, 0]`, the same as `iiwa14.json`. Upstream documents no home pose
(see `iiwa14/README_upstream.md`). With the gripper on, this pose is free of collision and inside
the limits. `grasp_link` is at (0.704, 0, 0.454) m in the base frame, in front of the base and
above it. The gripper's approach axis is about (0.43, 0, -0.90): pointing down, tilted about 25°
forward. A1, A3, A5 and A7 are 0, so the arm stays in the x-z plane and the total pitch is
0.5 + 1.2 + 1.0 = 2.7 rad.
