# fr3 (Franka Research 3 + Franka Hand): upstream provenance

- Upstream: https://github.com/frankarobotics/franka_description
- Commit: 7aeeddc449edf8d62b594f9e36a81da53e7796f9
- License: Apache-2.0 (`LICENSE` copied verbatim; upstream `NOTICE` copied verbatim too, as Apache-2.0 section 4(d) asks)

## Files used
- `robots/fr3/fr3.urdf.xacro` (entry point), `robots/fr3/{joint_limits,kinematics,inertials,dynamics,accelerometers}.yaml`
- `robots/common/{franka_robot,franka_arm,utils}.xacro`
- `end_effectors/common/{franka_hand,utils}.xacro`, `end_effectors/franka_hand/inertials.yaml`
- Meshes: `meshes/robots/fr3/{visual/*.dae,collision/*.stl}` (link0..link7) and
  `meshes/robot_ee/franka_hand_white/{visual/hand.dae,visual/finger.dae,collision/hand.stl}`,
  copied unchanged at the same relative paths.

## How the URDF was produced
Standalone xacro cannot resolve `$(find franka_description)`, so `robots/` and `end_effectors/`
were copied to a work dir and every `$(find franka_description)` was replaced by that dir's
absolute path (sed). Then, from the work dir:

    xacro robots/fr3/fr3.urdf.xacro hand:=true ee_id:=franka_hand

All other args at their upstream defaults (arm_prefix="", no_prefix=false, rpy_ee="0 0 -pi/4",
tcp_xyz="" -> franka_hand's 0 0 0.1034, with_sc=false, connected_to=base, xyz/rpy=0).

## Changes to the xacro output
- `package://franka_description/` stripped from every mesh filename, giving relative paths
  such as `meshes/robots/fr3/visual/link0.dae`.
- Removed four XML comments that echoed the work dir's absolute path (`Example definition: ...`).
- Nothing else: link/joint names, joint limits (upstream `joint_limits.yaml`), the
  `base` root link, the accelerometer frames, `fr3_link8`, `fr3_hand_tcp` (upstream TCP,
  0.1034 m from `fr3_hand`) and the finger box collision primitives are all as upstream emits them.

## SRDF
Generated with `tools/generate_srdf.py fr3/fr3.urdf fr3/fr3.srdf --end-effector fr3_hand_tcp --name fr3`
(srmp 0.2.1). One pair was then appended by hand:
`fr3_leftfinger` / `fr3_rightfinger`. Upstream's own `end_effectors/franka_hand/franka_hand.srdf.xacro`
disables exactly this pair (reason="Default"). Without it the robot is always in self-collision:
with the gripper closed (finger_joint1 = 0) the two rubber-tip collision boxes
(y = 7.58e-3 +/- 7.6e-3 in each finger frame) overlap by 0.04 mm, and the generator keeps the
pair enabled because it collides in only part of its samples.

## Default pose
`[0, -pi/4, 0, -3pi/4, 0, pi/2, pi/4]`: Franka's documented "ready" pose (franka_ros /
franka_ros2 `move_to_start` / MoveIt `ready` state, also the `panda` registry default).
Inside the FR3 limits (joint4 in [-3.077, -0.1169], joint6 in [0.4398, 4.6216]) and collision-free.
