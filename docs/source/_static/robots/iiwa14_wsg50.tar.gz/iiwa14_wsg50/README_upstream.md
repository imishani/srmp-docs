# iiwa14_wsg50 upstream (KUKA LBR iiwa 14 R820 + Schunk WSG 50)

This is the arm/gripper pairing of Drake's manipulation station: the iiwa 14 with a WSG 50 welded
to link 7.

## Sources

### Arm (license: Apache-2.0, file `LICENSE`)
The arm is copied unchanged from the staged `iiwa14` registry entry: the same links, joints,
limits, inertials, and meshes `meshes/visual/link_0..7.dae` and `meshes/collision/link_0..7.stl`.
- Description: https://github.com/lbr-stack/lbr_iiwa14_r820_description, tag v2.5.0, commit
  86ac0532841a90694afe6a65c300f08b55eb1296. Its package.xml declares Apache-2.0.
- LICENSE: the Apache-2.0 text from https://github.com/lbr-stack/lbr_fri_ros2_stack, commit
  f55f23d03e8dfeaafdd9d50fabf6a267445d753d.
- The full arm provenance (xacro command, path rewrites) is in iiwa14's README_upstream.md. In
  short: run xacro on `lbr_iiwa14_r820.urdf.xacro` with its default args (robot_name:=lbr), then
  rewrite `package://lbr_iiwa14_r820_description/meshes/...` to `meshes/...`.

### Gripper (license: BSD-3-Clause, Copyright 2020 Toyota Research Institute, file `LICENSE.wsg50`)
- Repo: https://github.com/RobotLocomotion/models (drake_models), commit
  f85076b4d95a8bdfec70153015e723e92312e4e2.
- Files used: `wsg_50_description/sdf/schunk_wsg_50_with_tip.sdf` (the variant Drake welds to the
  iiwa in its hardware_sim and manipulation scenarios), `wsg_50_description/meshes/wsg_body.gltf/.bin`,
  `wsg_50_description/meshes/finger_with_tip.gltf/.bin`, and `wsg_50_description/LICENSE`, which is
  copied verbatim as `LICENSE.wsg50`.
- Drake's README says TRI modeled these meshes from scratch from Schunk's catalogue drawing
  (WSG 050-110-P), not from Schunk's CADENAS model. So the BSD license covers them.

### Mounting and grasp frame (cited, no files copied)
- Repo: https://github.com/RobotLocomotion/drake, commit fe22ecd58f56a3d6290f29dcef52832b06fea796.
- `examples/hardware_sim/example_scenarios.yaml` (iiwa14 + schunk_wsg_50_with_tip.sdf) has the
  frame `wsg_on_iiwa` with base_frame `iiwa_link_7`, translation [0, 0, 0.114] and rotation
  `!Rpy {deg: [90, 0, 90]}`. That frame is welded to `wsg::body`. The same numbers appear in
  `manipulation/util/test/iiwa7_wsg.dmd.yaml` and `bindings/pydrake/visualization/test/multicam_scenario.yaml`.
- `manipulation/util/test/iiwa7_wsg.dmd.yaml` adds `schunk_wsg::grasp_frame` at
  `schunk_wsg::body_frame` + translation [0, 0.11, 0], with rotation rpy [0, 0, 0].
- `manipulation/schunk_wsg/schunk_wsg_position_controller.h`: "The physical gripper mechanically
  imposes that -q0 = q1".

## Converting Drake's iiwa_link_7 to this URDF's lbr_link_7
I ran FK at q = 0 on Drake's `iiwa_description/urdf/iiwa14_primitive_collision.urdf` (same models
commit). Drake's `iiwa_link_7` sits at z = 1.261 m, with the same orientation as the base. This
URDF's `lbr_link_7` sits at z = 1.271 m, also with identity orientation. Both models put the
flange at 1.306 m (Drake's `iiwa_link_ee` is 0.045 m past link 7; `lbr_link_ee` is 0.035 m past
link 7). Both A7 axes are +z of their link 7 frames. So X(lbr_link_7 -> iiwa_link_7) is a pure
translation (0, 0, -0.010), and the weld becomes:

    lbr_link_7 -> body: xyz (0, 0, 0.104), rpy (pi/2, 0, pi/2)

With that rotation, body +y maps to lbr_link_7 +z and body +x maps to lbr_link_7 +y. The fingers
sit at body +y, so they point along the flange's outward axis. I checked this with srmp FK at three
configurations (the default pose, zero, and a random one). In each, `grasp_frame` is 0.179 m from
`lbr_link_ee`, exactly along the flange z axis (0.104 + 0.110 - 0.035 = 0.179). The back face of
the WSG body is 0.033 m beyond the flange. That gap is Drake's unmodeled adapter plate, and I kept
it as in Drake.

## Gripper conversion (SDF -> URDF, by hand)
- Links `body`, `left_finger`, `right_finger` and joints `left_finger_sliding_joint`,
  `right_finger_sliding_joint` keep Drake's names. The weld joint is named `wsg_on_iiwa`, after
  Drake's frame.
- The SDF link poses are given in the model frame, where `body` is at (0, -0.049133, 0). I
  re-expressed them relative to `body`:
  - left_finger: xyz (-0.0115, 0.077133, 0), rpy (0, 3.141592, 0)
  - right_finger: xyz (0.0115, 0.077133, 0), rpy (0, 0, 0)

  SDF 1.7 gives a joint axis in the child frame, and URDF does the same, so the axes and limits are
  copied as they are. Left: axis (-1, 0, 0), limits [-0.055, 0]. Right: axis (1, 0, 0), limits
  [0, 0.055]. Effort is 80 for both. At q = 0 the gripper is closed. Opening is left -> -0.055,
  right -> +0.055.
- Mimic: Drake gives each finger its own actuator, but the real WSG 50 has one drive, and Drake's
  controller notes that the hardware imposes -q0 = q1. So `right_finger_sliding_joint` mimics
  `left_finger_sliding_joint` with multiplier -1 and offset 0. `left_finger_sliding_joint` is the
  actuated joint.
- Velocity limit: the SDF has none, and URDF requires one. I used 0.42 m/s, which is my choice,
  based on the WSG 50's rated gripping speed of up to 420 mm/s. Please verify this value.
- Inertials are copied from the SDF as they are. Drake's finger inertia (0.16 kg m^2) is a
  placeholder value.
- Collision geometry: Drake's primitive boxes are used as they are. Body: box 0.146 x 0.0725 x 0.05.
  Each finger: box 0.012 x 0.082 x 0.02. Each finger also has four 0.001 m contact-point spheres
  for Drake's point contact. I dropped them because they lie on the inner pad face and add nothing
  for planning.
- Visual meshes: Drake ships these meshes only as glTF; no .obj/.stl/.dae exists. I converted
  `wsg_body.gltf` and `finger_with_tip.gltf` (one mesh each, no node transforms) to
  `meshes/wsg50/wsg_body.obj` and `meshes/wsg50/finger_with_tip.obj` with a short script. The
  script copies the vertices, normals and triangles exactly (no decimation). It also applies the
  y-up -> z-up rotation Drake applies to glTF, (x, y, z) -> (x, -z, y). I checked the result
  against the SDF: the body's bounding box becomes 0.146 x 0.0725 x 0.05, which matches the
  collision box. The finger's narrow 0.02 m tip ends up at finger +y, at x = -0.009, where the SDF
  puts its pad contact spheres (y 0.021..0.041, x = -0.008). The other glTF/vtk/bubble meshes are
  not used.
- End effector: `grasp_frame`, a fixed link added at `body` + (0, 0.11, 0) with the same
  orientation as `body`, following Drake's `grasp_frame` directive. It lies between the fingertip
  pads, which span body y 0.098..0.118. Drake's grasp_frame approaches along +y; here it is rotated by -pi/2 about x (rpy -pi/2 0 0) so its +z is the approach axis, like the other registry end effectors.

## SRDF
Generated with:

    python /home/itamar/work/code/ims_manip/tools/generate_srdf.py iiwa14_wsg50/iiwa14_wsg50.urdf iiwa14_wsg50/iiwa14_wsg50.srdf --end-effector grasp_frame --name iiwa14_wsg50

The generator output had 59 disable lines. Two corrections followed, using `fix_srdf.py`:
1. `--default`: none. At gripper q = 0 the finger collision boxes are 11 mm apart (inner faces at
   body x = +-0.0055), so the closed fingers do not touch. The finger boxes overlap the body box
   by 0.1 mm, but those pairs are parent/child and already disabled.
2. `--enable lbr_link_2:left_finger lbr_link_2:right_finger`: `probe_srdf.py iiwa14_wsg50
   iiwa14_wsg50.json 20000` reported these two pairs as HIDDEN (3 and 4 colliding samples). A
   re-run of the probe found 0 hidden pairs. iiwa14's own correction (`lbr_link_0`/`lbr_link_7`)
   was not needed here, because this generator run left that pair enabled.

## default_qpos
[0, 0.5, 0, -1.2, 0, 1.0, 0] rad, the same pose as `iiwa14.json`. KUKA documents no home pose; see
iiwa14's README. With the gripper attached it is free of collision. `grasp_frame` is at
(0.728, 0, 0.401) m with the approach axis pointing mostly down.

## Adapter plate (added)

Drake's weld leaves 0.0328 m between the iiwa flange (`lbr_link_ee`) and the back face of the
WSG body, where the real adapter plate sits; Drake does not model it. Link `wsg_adapter` fills
that gap with a plain cylinder (diameter 0.063 m, the flange's, length 0.0328 m), visual and
collision. It is an approximation, not a manufacturer model. The SRDF was regenerated with it
and the two corrections re-applied (see above), then re-probed.
