# wx250s: Interbotix WidowX 250 6DOF (wx250s) with the standard Interbotix gripper

## Upstream
- Repo: https://github.com/Interbotix/interbotix_ros_manipulators
- Branch: `main` (the ROS 1 Noetic branch; it contains `interbotix_ros_xsarms/interbotix_xsarm_descriptions`, so no ROS 2 branch was needed)
- Commit: 0bb2b0e6d0e619bff02cf74dbd5af5681dcf80c9 (2024-07-10)
- License: BSD-3-Clause (repo-root `LICENSE`, copied verbatim; package.xml says `BSD`)

## Files used
- `interbotix_ros_xsarms/interbotix_xsarm_descriptions/urdf/wx250s.urdf.xacro`
- `interbotix_ros_xsarms/interbotix_xsarm_descriptions/meshes/wx250s_meshes/wx250s_{1_base,2_shoulder,3_upper_arm,4_upper_forearm,5_lower_forearm,6_wrist,7_gripper,8_gripper_prop,9_gripper_bar,10_gripper_finger}.stl`
- `interbotix_ros_xsarms/interbotix_xsarm_descriptions/meshes/interbotix_black.png` (material texture)
- `LICENSE` (repo root)

## xacro command
```
xacro interbotix_xsarm_descriptions/urdf/wx250s.urdf.xacro \
  robot_name:=wx250s show_ar_tag:=false show_gripper_bar:=true show_gripper_fingers:=true \
  use_world_frame:=false load_gazebo_configs:=false > wx250s.urdf
```
(`base_link_frame` and `external_urdf_loc` left at defaults: `base_link`, empty.)
These are the upstream defaults: no AR tag, no world frame, no Gazebo configs, and no
external URDF (camera etc.). The gripper bar and fingers are on.

## Changes
- `package://interbotix_xsarm_descriptions/meshes/wx250s_meshes/<f>` became `meshes/<f>`, and
  `package://interbotix_xsarm_descriptions/meshes/interbotix_black.png` became
  `meshes/interbotix_black.png`. That is the only edit to the xacro output.
- Link and joint names, geometry, limits and the `right_finger` mimic are unchanged. Links are
  prefixed with the model name (`wx250s/base_link` and so on), as upstream does. The
  ROS 1 `<transmission>` blocks are kept as generated.
- Meshes are the upstream STLs (scale 0.001 in the URDF), not modified or decimated. The visual
  and collision geometry are the same meshes, as upstream has them.
- The AR-tag mesh (`wx250s_11_ar_tag.stl`) is not included because it is not referenced.
- `wx250s.srdf` was generated with
  `tools/generate_srdf.py wx250s/wx250s.urdf wx250s/wx250s.srdf --end-effector wx250s/ee_gripper_link --name wx250s`.

## Manifest choices
- End effector: `wx250s/ee_gripper_link`. This is the upstream frame between the fingers, fixed
  joint `ee_gripper` from `fingers_link`. No TCP link was added.
- Arm joints: waist, shoulder, elbow, forearm_roll, wrist_angle, wrist_rotate.
- Gripper joints: `gripper` (continuous; the motor horn that spins `gripper_prop_link`),
  `left_finger` (prismatic, 0.015 .. 0.037 m), and `right_finger` (mimic of left_finger, multiplier -1).
- default_qpos: all zeros. This is Interbotix's "Home" pose (`go_to_home_pose()` in
  interbotix_xs_modules sends every arm joint to 0). There the arm stretches forward with the
  upper arm vertical, the forearm horizontal and the gripper pointing along +x. The EE sits in
  front of the base and above it. The pose is inside the limits and free of self-collision
  as long as the fingers are inside their limits (see the caveat below).

## Caveat: finger joints at 0
srmp starts gripper joints at 0. The finger lower limits are above 0 (0.015 .. 0.037 m per finger), and at
0 the two finger meshes overlap, so every arm configuration reports a self-collision until the
gripper is set inside its limits, e.g. `set_gripper_qpos(name, [0, lower, -lower])`.
